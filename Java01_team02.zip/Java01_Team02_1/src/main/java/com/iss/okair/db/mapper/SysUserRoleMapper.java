package com.iss.okair.db.mapper;

import java.util.List;

import com.iss.okair.db.entity.SysUserRole;

public interface SysUserRoleMapper {
	
	List<SysUserRole> selectAll();
	
}
