package com.iss.okair.db.entity;

public class EmployeeDept {
	private String dept;

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}
	
}
