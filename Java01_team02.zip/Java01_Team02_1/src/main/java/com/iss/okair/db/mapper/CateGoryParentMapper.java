package com.iss.okair.db.mapper;

import java.util.List;

import com.iss.okair.db.entity.CateGoryParent;

public interface CateGoryParentMapper {
	List<CateGoryParent> selectAll(); 
}
