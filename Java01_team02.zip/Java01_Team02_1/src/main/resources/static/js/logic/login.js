/**
 * 
 */
requirejs(['../common'], function(common) {
	
	requirejs(['logic/model/loginModel']);
	
});

