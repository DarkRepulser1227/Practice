/**
 * 
 */
requirejs(["../common"], function(Common) {
	// 加载页面核心模块
	requirejs(["logic/model/trans/financeTransModel"]);
	
});

