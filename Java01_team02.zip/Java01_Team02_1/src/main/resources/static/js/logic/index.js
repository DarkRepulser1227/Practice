/**
 * 
 */
requirejs(["../common"], function(Common) {
	
	requirejs(["logic/model/indexModel"]);
	
});

